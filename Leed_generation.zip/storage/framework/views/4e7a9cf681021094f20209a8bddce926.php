<?php $__env->startSection('title', 'Setup & health'); ?>
<?php $__env->startSection('content'); ?>
<?php $c = collect($checks); ?>
<h3 class="fw-bold mb-1">Setup &amp; health</h3>
<p class="text-muted small">Live checks of this installation. Only items marked <strong>FAIL</strong> or <strong>WARN</strong> need you. CLI: <code>php artisan leadpilot:doctor</code> · real-data test: <code>php artisan leadpilot:validate-live</code></p>
<form method="POST" action="<?php echo e(route('autopilot.setup.defaults')); ?>" class="mb-3"><?php echo csrf_field(); ?><button class="btn btn-sm btn-primary-lp"><i class="bi bi-magic"></i> Apply recommended defaults</button>
    <span class="small text-muted ms-2">Fixes demo Reply-To, approves services your ICPs target, sets timezone, creates starter ICPs. Never touches credentials or billing.</span></form>
<div class="d-flex gap-2 mb-3"><span class="badge bg-success"><?php echo e($c->where('status','ok')->count()); ?> OK</span><span class="badge bg-warning text-dark"><?php echo e($c->where('status','warn')->count()); ?> WARN</span><span class="badge bg-danger"><?php echo e($c->where('status','fail')->count()); ?> FAIL</span><span class="badge bg-secondary"><?php echo e($c->where('status','info')->count()); ?> OPTIONAL / PENDING FIRST USE</span></div>
<div class="card-lp p-0">
<table class="table table-lp small align-middle mb-0"><thead><tr class="text-muted"><th class="ps-3">Status</th><th>Check</th><th>Detail</th><th>How to fix</th></tr></thead><tbody>
<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $c->sortBy(fn($x) => ['fail'=>0,'warn'=>1,'ok'=>2,'info'=>3][$x['status']] ?? 4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
    <tr><td class="ps-3"><span class="badge <?php echo e(['ok'=>'bg-success','warn'=>'bg-warning text-dark','fail'=>'bg-danger','info'=>'bg-secondary'][$x['status']] ?? 'bg-light'); ?>"><?php echo e($x['status'] === 'info' ? 'OPTIONAL' : strtoupper($x['status'])); ?></span></td>
        <td class="fw-semibold"><?php echo e($x['label']); ?></td><td><?php echo e($x['detail']); ?></td><td class="text-muted"><?php echo e($x['fix']); ?></td></tr>
<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
</tbody></table></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Leed_generation\resources\views/autopilot/setup.blade.php ENDPATH**/ ?>