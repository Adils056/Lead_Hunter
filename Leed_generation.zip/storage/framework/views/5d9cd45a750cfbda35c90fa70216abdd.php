<?php $__env->startSection('title', 'Campaign Automation'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
    <div>
        <h3 class="fw-bold mb-1">Outreach Campaigns</h3>
        <p class="text-muted small mb-0">Personalized email campaigns with compliance guardrails, manual approval gates, and daily throttling.</p>
    </div>

    <a href="<?php echo e(route('campaigns.create')); ?>" class="btn btn-sm btn-primary-lp d-flex align-items-center gap-1">
        <i class="bi bi-plus-circle"></i>
        <span>Create Campaign</span>
    </a>
</div>

<div class="card-lp overflow-hidden mb-4">
    <div class="table-responsive">
        <table class="table table-lp align-middle">
            <thead>
                <tr>
                    <th>Campaign & Service Offered</th>
                    <th>Targeting Rules</th>
                    <th class="text-center">Min Score</th>
                    <th class="text-center">Recipients</th>
                    <th class="text-center">Delivered</th>
                    <th class="text-center">Replies</th>
                    <th>Status & Approval</th>
                    <th class="text-end">Controls</th>
                </tr>
            </thead>
            <tbody>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $campaigns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $camp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <tr>
                    <td>
                        <a href="<?php echo e(route('campaigns.show', $camp)); ?>" class="fw-bold text-dark text-decoration-none fs-6">
                            <?php echo e($camp->name); ?>

                        </a>
                        <div class="small text-muted">
                            <i class="bi bi-tag me-1"></i><?php echo e($camp->service_offered); ?>

                        </div>
                    </td>

                    <td>
                        <div class="small text-dark fw-semibold">
                            <?php echo e(!empty($camp->target_countries) ? implode(', ', (array) $camp->target_countries) : 'All Countries'); ?>

                        </div>
                        <div class="small text-muted">Limit: <?php echo e($camp->daily_limit); ?>/day</div>
                    </td>

                    <td class="text-center">
                        <span class="badge bg-light text-dark border"><?php echo e($camp->min_lead_score); ?>+ pts</span>
                    </td>

                    <td class="text-center">
                        <span class="badge bg-light text-dark border"><?php echo e($camp->total_recipients); ?></span>
                    </td>

                    <td class="text-center">
                        <span class="badge bg-success-subtle text-success border"><?php echo e($camp->delivered_count); ?></span>
                    </td>

                    <td class="text-center">
                        <span class="badge bg-primary-subtle text-primary border"><?php echo e($camp->replied_count); ?></span>
                    </td>

                    <td>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($camp->emergency_stopped): ?>
                            <span class="badge bg-danger">HALTED (Emergency Stop)</span>
                        <?php elseif($camp->status === 'running'): ?>
                            <span class="badge bg-success">Running</span>
                        <?php elseif($camp->status === 'paused'): ?>
                            <span class="badge bg-warning text-dark">Paused</span>
                        <?php elseif($camp->status === 'approved'): ?>
                            <span class="badge bg-info text-dark">Approved</span>
                        <?php else: ?>
                            <span class="badge bg-secondary">Draft (Needs Approval)</span>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </td>

                    <td class="text-end">
                        <div class="btn-group btn-group-sm">
                            <a href="<?php echo e(route('campaigns.show', $camp)); ?>" class="btn btn-light border" title="View Campaign Management">
                                <i class="bi bi-eye"></i>
                            </a>

                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(Auth::user()?->isAdmin() && $camp->status === 'draft'): ?>
                            <form action="<?php echo e(route('campaigns.approve', $camp)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-light border text-success" title="Approve Campaign">
                                    <i class="bi bi-check-circle"></i>
                                </button>
                            </form>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($camp->status === 'running'): ?>
                            <form action="<?php echo e(route('campaigns.pause', $camp)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-light border text-warning" title="Pause Campaign">
                                    <i class="bi bi-pause-circle"></i>
                                </button>
                            </form>
                            <?php elseif($camp->status === 'paused' && !$camp->emergency_stopped): ?>
                            <form action="<?php echo e(route('campaigns.resume', $camp)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-light border text-success" title="Resume Campaign">
                                    <i class="bi bi-play-circle"></i>
                                </button>
                            </form>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                    </td>
                </tr>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                <tr>
                    <td colspan="8" class="text-center py-5 text-muted">
                        <i class="bi bi-send-x fs-1 d-block mb-2 opacity-50"></i>
                        No outreach campaigns configured yet.
                    </td>
                </tr>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($campaigns->hasPages()): ?>
    <div class="p-3 border-top bg-light-subtle d-flex justify-content-end">
        <?php echo e($campaigns->links()); ?>

    </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Leed_generation\resources\views/campaigns/index.blade.php ENDPATH**/ ?>