<?php $__env->startSection('title', 'Analytics & Reporting'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
    <div>
        <h3 class="fw-bold mb-1">Sales Intelligence & Campaign Analytics</h3>
        <p class="text-muted small mb-0">Database-backed conversion metrics, funnel velocity, and customer acquisition costs.</p>
    </div>

    <div class="d-flex gap-2">
        <a href="<?php echo e(route('analytics.export', ['days' => $days])); ?>" class="btn btn-sm btn-outline-secondary d-flex align-items-center gap-1">
            <i class="bi bi-download"></i>
            <span>Export Report CSV</span>
        </a>
        <form action="<?php echo e(route('analytics.index')); ?>" method="GET" class="d-flex gap-1">
            <select name="days" class="form-select form-select-sm" onchange="this.form.submit()">
                <option value="7" <?php echo e($days == 7 ? 'selected' : ''); ?>>Last 7 Days</option>
                <option value="30" <?php echo e($days == 30 ? 'selected' : ''); ?>>Last 30 Days</option>
                <option value="90" <?php echo e($days == 90 ? 'selected' : ''); ?>>Last 90 Days</option>
            </select>
        </form>
    </div>
</div>

<!-- Conversion Funnel Row -->
<div class="row g-3 mb-4">
    <div class="col-6 col-md-4 col-xl-2">
        <div class="card-lp p-3 text-center">
            <div class="text-muted small fw-semibold text-uppercase">Discovered</div>
            <div class="fs-4 fw-bold mt-1 text-dark"><?php echo e($totalLeads); ?></div>
            <div class="small text-muted">Total Prospects</div>
        </div>
    </div>
    <div class="col-6 col-md-4 col-xl-2">
        <div class="card-lp p-3 text-center">
            <div class="text-muted small fw-semibold text-uppercase">Verified Deliverable</div>
            <div class="fs-4 fw-bold mt-1 text-info"><?php echo e($verifiedLeads); ?></div>
            <div class="small text-info fw-semibold"><?php echo e($verificationRate); ?>% Rate</div>
        </div>
    </div>
    <div class="col-6 col-md-4 col-xl-2">
        <div class="card-lp p-3 text-center">
            <div class="text-muted small fw-semibold text-uppercase">Qualified (60+)</div>
            <div class="fs-4 fw-bold mt-1 text-primary"><?php echo e($qualifiedLeads); ?></div>
            <div class="small text-primary fw-semibold"><?php echo e($qualificationRate); ?>% Rate</div>
        </div>
    </div>
    <div class="col-6 col-md-4 col-xl-2">
        <div class="card-lp p-3 text-center">
            <div class="text-muted small fw-semibold text-uppercase">Delivered</div>
            <div class="fs-4 fw-bold mt-1 text-success"><?php echo e($delivered); ?></div>
            <div class="small text-success fw-semibold"><?php echo e($deliveryRate); ?>% of Sent</div>
        </div>
    </div>
    <div class="col-6 col-md-4 col-xl-2">
        <div class="card-lp p-3 text-center">
            <div class="text-muted small fw-semibold text-uppercase">Inbound Replies</div>
            <div class="fs-4 fw-bold mt-1 text-purple" style="color: #6366f1;"><?php echo e($replies); ?></div>
            <div class="small text-muted"><?php echo e($positiveReplies); ?> Positive</div>
        </div>
    </div>
    <div class="col-6 col-md-4 col-xl-2">
        <div class="card-lp p-3 text-center">
            <div class="text-muted small fw-semibold text-uppercase">Won Deals</div>
            <div class="fs-4 fw-bold mt-1 text-success"><?php echo e($wonDeals); ?></div>
            <div class="small text-success fw-bold">$<?php echo e(number_format($wonRevenue)); ?></div>
        </div>
    </div>
</div>

<!-- Cost & ROI Analysis -->
<div class="card-lp p-4 mb-4" style="background: linear-gradient(135deg, #f8fafc 0%, #ede9fe 100%);">
    <div class="row g-4 align-items-center">
        <div class="col-md-4">
            <span class="text-muted small text-uppercase fw-bold">Total External API Spend</span>
            <div class="fs-3 fw-bold text-dark mt-1">$<?php echo e(number_format($totalCost, 4)); ?></div>
            <div class="small text-muted">OpenAI analysis, Hunter credits & verified infrastructure</div>
        </div>
        <div class="col-md-4 border-start-md">
            <span class="text-muted small text-uppercase fw-bold">Cost Per Qualified Lead (CPQL)</span>
            <div class="fs-3 fw-bold text-primary mt-1">$<?php echo e(number_format($costPerQualifiedLead, 2)); ?></div>
            <div class="small text-muted">Across <?php echo e($qualifiedLeads); ?> qualified enterprise prospects</div>
        </div>
        <div class="col-md-4 border-start-md">
            <span class="text-muted small text-uppercase fw-bold">Cost Per Booked Discovery Meeting</span>
            <div class="fs-3 fw-bold text-success mt-1">$<?php echo e(number_format($costPerMeeting, 2)); ?></div>
            <div class="small text-muted">High-converting technical discovery calls</div>
        </div>
    </div>
</div>

<!-- Charts Row -->
<div class="row g-4 mb-4">
    <!-- Leads by Country Chart -->
    <div class="col-lg-7">
        <div class="card-lp p-4 h-100">
            <h6 class="fw-bold mb-3">Lead Concentration by Target Country</h6>
            <div style="height: 280px;">
                <canvas id="leadsByCountryChart"></canvas>
            </div>
        </div>
    </div>

    <!-- Score Distribution Donut Chart -->
    <div class="col-lg-5">
        <div class="card-lp p-4 h-100">
            <h6 class="fw-bold mb-3">Lead Priority Score Distribution</h6>
            <div style="height: 240px;" class="d-flex justify-content-center">
                <canvas id="scoreDistChart"></canvas>
            </div>
            <div class="d-flex justify-content-around text-center small text-muted mt-3 pt-2 border-top">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $scoreDistribution; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <div>
                    <strong><?php echo e($val); ?></strong>
                    <div style="font-size: 0.7rem;"><?php echo e(explode(' ', $label)[0]); ?></div>
                </div>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Source Performance Table -->
<div class="card-lp overflow-hidden mb-4">
    <div class="p-3 border-bottom bg-light-subtle d-flex justify-content-between align-items-center">
        <h6 class="fw-bold mb-0">Lead Discovery Source Performance</h6>
        <span class="small text-muted">Real database aggregated results</span>
    </div>
    <div class="table-responsive">
        <table class="table table-lp align-middle">
            <thead>
                <tr>
                    <th>Lead Source Name</th>
                    <th class="text-center">Total Discovered</th>
                    <th class="text-center">Average Score</th>
                    <th>Quality Assessment</th>
                </tr>
            </thead>
            <tbody>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $leadsBySource; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $src): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <tr>
                    <td class="fw-bold text-dark"><?php echo e($src->source_name); ?></td>
                    <td class="text-center"><span class="badge bg-light text-dark border"><?php echo e($src->count); ?></span></td>
                    <td class="text-center"><span class="fw-bold text-primary"><?php echo e(round($src->avg_score, 1)); ?> pts</span></td>
                    <td>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($src->avg_score >= 75): ?>
                            <span class="badge bg-success-subtle text-success">High Converting Source</span>
                        <?php elseif($src->avg_score >= 50): ?>
                            <span class="badge bg-primary-subtle text-primary">Solid B2B Fit</span>
                        <?php else: ?>
                            <span class="badge bg-secondary-subtle text-secondary">General Inflow</span>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </td>
                </tr>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener("DOMContentLoaded", function() {
    // 1. Leads By Country Chart
    const countryLabels = <?php echo json_encode($leadsByCountry->pluck('country'), 15, 512) ?>;
    const countryCounts = <?php echo json_encode($leadsByCountry->pluck('count'), 15, 512) ?>;

    new Chart(document.getElementById('leadsByCountryChart'), {
        type: 'bar',
        data: {
            labels: countryLabels,
            datasets: [{
                label: 'Prospects',
                data: countryCounts,
                backgroundColor: '#4f46e5',
                borderRadius: 6,
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: {
                y: { beginAtZero: true, ticks: { precision: 0 } },
                x: { grid: { display: false } }
            }
        }
    });

    // 2. Score Distribution Donut
    const scoreData = <?php echo json_encode($scoreDistribution, 15, 512) ?>;
    new Chart(document.getElementById('scoreDistChart'), {
        type: 'doughnut',
        data: {
            labels: Object.keys(scoreData),
            datasets: [{
                data: Object.values(scoreData),
                backgroundColor: ['#10b981', '#f59e0b', '#64748b', '#ef4444'],
                borderWidth: 2,
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { position: 'bottom', labels: { boxWidth: 12, font: { size: 10 } } }
            },
            cutout: '70%'
        }
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Leed_generation\resources\views/analytics/index.blade.php ENDPATH**/ ?>