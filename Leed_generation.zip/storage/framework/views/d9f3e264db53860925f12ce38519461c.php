<?php $__env->startSection('title', 'Buying Intent Signals'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
    <div>
        <h3 class="fw-bold mb-1">Buying Intent Signal Engine</h3>
        <p class="text-muted small mb-0">Observed market opportunities: hiring posts, project tenders, tech changes, and procurement RFPs.</p>
    </div>

    <a href="<?php echo e(route('buying-signals.create')); ?>" class="btn btn-sm btn-primary-lp d-flex align-items-center gap-1">
        <i class="bi bi-plus-lg"></i>
        <span>Log Buying Signal</span>
    </a>
</div>

<!-- Filters -->
<div class="card-lp p-3 mb-4">
    <form action="<?php echo e(route('buying-signals.index')); ?>" method="GET" class="row g-2 align-items-center">
        <div class="col-md-3">
            <select name="status" class="form-select form-select-sm" onchange="this.form.submit()">
                <option value="all" <?php echo e($status == 'all' ? 'selected' : ''); ?>>All Verification Statuses</option>
                <option value="verified" <?php echo e($status == 'verified' ? 'selected' : ''); ?>>Verified Only</option>
                <option value="unverified" <?php echo e($status == 'unverified' ? 'selected' : ''); ?>>Unverified</option>
                <option value="dismissed" <?php echo e($status == 'dismissed' ? 'selected' : ''); ?>>Dismissed</option>
            </select>
        </div>
        <div class="col-md-4">
            <select name="type" class="form-select form-select-sm" onchange="this.form.submit()">
                <option value="">All Signal Categories</option>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $signalTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sKey => $sLabel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <option value="<?php echo e($sKey); ?>" <?php echo e($type == $sKey ? 'selected' : ''); ?>><?php echo e($sLabel); ?></option>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </select>
        </div>
        <div class="col-md-3">
            <select name="service" class="form-select form-select-sm" onchange="this.form.submit()">
                <option value="">All Agency Services</option>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = [
                    'Laravel and PHP development',
                    'ERP and CRM development',
                    'Custom software development',
                    'E-commerce development',
                    'API development and integration',
                    'SaaS product development',
                    'Database design, optimization, and system integrations'
                ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $srv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <option value="<?php echo e($srv); ?>" <?php echo e($service == $srv ? 'selected' : ''); ?>><?php echo e($srv); ?></option>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </select>
        </div>
        <div class="col-md-2 d-flex gap-2">
            <button type="submit" class="btn btn-sm btn-light border w-100"><i class="bi bi-funnel me-1"></i>Filter</button>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($status !== 'all' || $type || $service): ?>
                <a href="<?php echo e(route('buying-signals.index')); ?>" class="btn btn-sm btn-light border text-danger"><i class="bi bi-x-lg"></i></a>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </form>
</div>

<!-- Signals List -->
<div class="row g-3 mb-4">
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $signals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $signal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
    <div class="col-lg-6">
        <div class="card-lp p-4 h-100 position-relative">
            <div class="d-flex justify-content-between align-items-start mb-2">
                <div>
                    <span class="badge bg-light text-dark border mb-1" style="font-size: 0.725rem;">
                        <?php echo e($signalTypes[$signal->signal_type] ?? ucwords(str_replace('_', ' ', $signal->signal_type))); ?>

                    </span>
                    <h5 class="fw-bold text-dark fs-6 mb-1"><?php echo e($signal->title); ?></h5>
                    <div class="small text-muted">
                        <i class="bi bi-building me-1"></i>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($signal->company): ?>
                            <a href="<?php echo e(route('companies.show', $signal->company)); ?>" class="fw-semibold text-decoration-none">
                                <?php echo e($signal->company->name); ?> (<?php echo e($signal->company->country); ?>)
                            </a>
                        <?php else: ?>
                            <span>Unlinked Company</span>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                </div>

                <div class="text-end">
                    <span class="badge <?php echo e($signal->confidence >= 85 ? 'bg-success-subtle text-success' : 'bg-primary-subtle text-primary'); ?> border">
                        <?php echo e($signal->confidence); ?>% Conf
                    </span>
                    <div class="small text-muted mt-1" style="font-size: 0.7rem;">
                        <?php echo e($signal->isFresh() ? 'Fresh (<60d)' : 'Aged'); ?>

                    </div>
                </div>
            </div>

            <p class="text-secondary small mb-3" style="line-height: 1.5;">
                <?php echo e($signal->evidence_text); ?>

            </p>

            <div class="p-2 rounded bg-light border small text-muted d-flex justify-content-between align-items-center mb-3" style="font-size: 0.75rem;">
                <div>
                    <strong class="text-dark">Service Fit:</strong> <?php echo e($signal->relevant_service); ?>

                </div>
                <div>
                    <span>Observed: <?php echo e($signal->observed_date->format('M d, Y')); ?></span>
                </div>
            </div>

            <div class="d-flex justify-content-between align-items-center pt-2 border-top">
                <div>
                    <span class="badge <?php echo e($signal->verification_status === 'verified' ? 'bg-success' : ($signal->verification_status === 'dismissed' ? 'bg-danger' : 'bg-warning text-dark')); ?>">
                        <?php echo e(ucfirst($signal->verification_status)); ?>

                    </span>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($signal->source_url): ?>
                        <a href="<?php echo e($signal->source_url); ?>" target="_blank" class="small text-muted text-decoration-none ms-2">
                            <i class="bi bi-box-arrow-up-right me-1"></i>Evidence Link
                        </a>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>

                <div class="btn-group btn-group-sm">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($signal->verification_status !== 'verified'): ?>
                    <form action="<?php echo e(route('buying-signals.status', $signal)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="verification_status" value="verified">
                        <button type="submit" class="btn btn-sm btn-outline-success py-1 px-2" title="Verify Signal">
                            <i class="bi bi-check-lg me-1"></i>Verify
                        </button>
                    </form>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($signal->verification_status !== 'dismissed'): ?>
                    <form action="<?php echo e(route('buying-signals.status', $signal)); ?>" method="POST" class="ms-1">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="verification_status" value="dismissed">
                        <button type="submit" class="btn btn-sm btn-outline-danger py-1 px-2" title="Dismiss Signal">
                            <i class="bi bi-x-lg me-1"></i>Dismiss
                        </button>
                    </form>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
    <div class="col-12">
        <div class="card-lp p-5 text-center text-muted">
            <i class="bi bi-broadcast fs-1 opacity-50 d-block mb-2"></i>
            No buying intent signals match the selected filters.
        </div>
    </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</div>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($signals->hasPages()): ?>
<div class="d-flex justify-content-end mb-4">
    <?php echo e($signals->links()); ?>

</div>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Leed_generation\resources\views/buying_signals/index.blade.php ENDPATH**/ ?>