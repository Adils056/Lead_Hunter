<?php $__env->startSection('title', $campaign->name . ' — Campaign Details'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-4">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb mb-2" style="font-size: 0.825rem;">
            <li class="breadcrumb-item"><a href="<?php echo e(route('campaigns.index')); ?>">Campaigns</a></li>
            <li class="breadcrumb-item active"><?php echo e($campaign->name); ?></li>
        </ol>
    </nav>

    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3">
        <div>
            <div class="d-flex align-items-center gap-2">
                <h3 class="fw-bold mb-0"><?php echo e($campaign->name); ?></h3>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($campaign->emergency_stopped): ?>
                    <span class="badge bg-danger">HALTED (Emergency Stop)</span>
                <?php elseif($campaign->status === 'running'): ?>
                    <span class="badge bg-success">Running</span>
                <?php elseif($campaign->status === 'approved'): ?>
                    <span class="badge bg-info text-dark">Approved</span>
                <?php elseif($campaign->status === 'paused'): ?>
                    <span class="badge bg-warning text-dark">Paused</span>
                <?php else: ?>
                    <span class="badge bg-secondary">Draft / Awaiting Review</span>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
            <div class="d-flex flex-wrap align-items-center gap-3 text-muted small mt-1">
                <span><i class="bi bi-tag me-1"></i><?php echo e($campaign->service_offered); ?></span>
                <span><i class="bi bi-speedometer2 me-1"></i>Daily Quota: <?php echo e($campaign->sent_today); ?> / <?php echo e($campaign->daily_limit); ?> sent today</span>
                <span><i class="bi bi-person me-1"></i>Created by <?php echo e($campaign->creator?->name); ?></span>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($campaign->approved_by): ?>
                    <span><i class="bi bi-shield-check text-success me-1"></i>Approved by <?php echo e($campaign->approver?->name); ?></span>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>

        <div class="d-flex gap-2">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(Auth::user()?->isAdmin() && $campaign->status === 'draft'): ?>
            <form action="<?php echo e(route('campaigns.approve', $campaign)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-sm btn-success d-flex align-items-center gap-1 shadow-sm">
                    <i class="bi bi-check-circle"></i>
                    <span>Approve & Start Campaign</span>
                </button>
            </form>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($campaign->status === 'running'): ?>
            <form action="<?php echo e(route('campaigns.pause', $campaign)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-sm btn-light border text-warning d-flex align-items-center gap-1">
                    <i class="bi bi-pause-circle"></i>
                    <span>Pause</span>
                </button>
            </form>
            <?php elseif($campaign->status === 'paused' && !$campaign->emergency_stopped): ?>
            <form action="<?php echo e(route('campaigns.resume', $campaign)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-sm btn-light border text-success d-flex align-items-center gap-1">
                    <i class="bi bi-play-circle"></i>
                    <span>Resume</span>
                </button>
            </form>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!$campaign->emergency_stopped && Auth::user()?->isAdmin()): ?>
            <form action="<?php echo e(route('campaigns.emergency-stop', $campaign)); ?>" method="POST" onsubmit="return confirm('WARNING: Are you sure you want to trigger the global emergency stop for this campaign? All outbound queues will halt immediately.')">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-sm btn-outline-danger d-flex align-items-center gap-1">
                    <i class="bi bi-radioactive"></i>
                    <span>Emergency Stop</span>
                </button>
            </form>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>
</div>

<!-- Metrics Bar -->
<div class="row g-3 mb-4">
    <div class="col-6 col-md-3 col-xl">
        <div class="card-lp p-3 text-center">
            <div class="text-muted small fw-semibold text-uppercase">Enrolled</div>
            <div class="fs-4 fw-bold mt-1 text-dark"><?php echo e($metrics['total']); ?></div>
        </div>
    </div>
    <div class="col-6 col-md-3 col-xl">
        <div class="card-lp p-3 text-center">
            <div class="text-muted small fw-semibold text-uppercase">Drafts</div>
            <div class="fs-4 fw-bold mt-1 text-secondary"><?php echo e($metrics['draft']); ?></div>
        </div>
    </div>
    <div class="col-6 col-md-3 col-xl">
        <div class="card-lp p-3 text-center">
            <div class="text-muted small fw-semibold text-uppercase">Approved</div>
            <div class="fs-4 fw-bold mt-1 text-info"><?php echo e($metrics['approved']); ?></div>
        </div>
    </div>
    <div class="col-6 col-md-3 col-xl">
        <div class="card-lp p-3 text-center">
            <div class="text-muted small fw-semibold text-uppercase">Dispatched</div>
            <div class="fs-4 fw-bold mt-1 text-primary"><?php echo e($metrics['sent']); ?></div>
        </div>
    </div>
    <div class="col-6 col-md-3 col-xl">
        <div class="card-lp p-3 text-center">
            <div class="text-muted small fw-semibold text-uppercase">Delivered</div>
            <div class="fs-4 fw-bold mt-1 text-success"><?php echo e($metrics['delivered']); ?></div>
        </div>
    </div>
    <div class="col-6 col-md-3 col-xl">
        <div class="card-lp p-3 text-center">
            <div class="text-muted small fw-semibold text-uppercase">Replies</div>
            <div class="fs-4 fw-bold mt-1 text-purple" style="color: #6366f1;"><?php echo e($metrics['replied']); ?></div>
        </div>
    </div>
    <div class="col-6 col-md-3 col-xl">
        <div class="card-lp p-3 text-center">
            <div class="text-muted small fw-semibold text-uppercase">Bounced</div>
            <div class="fs-4 fw-bold mt-1 text-danger"><?php echo e($metrics['bounced']); ?></div>
        </div>
    </div>
</div>

<div class="row g-4 mb-4">
    <!-- Test Email Dispatch Card -->
    <div class="col-lg-6">
        <div class="card-lp p-4 h-100">
            <h6 class="fw-bold mb-2"><i class="bi bi-send-exclamation text-primary me-1"></i> Send Safe Test Email</h6>
            <p class="text-muted small mb-3">Send a sample formatted email to an administrative inbox before approving live sends.</p>
            <form action="<?php echo e(route('campaigns.test-email', $campaign)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="input-group input-group-sm mb-2">
                    <span class="input-group-text bg-light"><i class="bi bi-envelope"></i></span>
                    <input type="email" name="test_email" class="form-control" placeholder="admin@leadpilot.test" value="<?php echo e(Auth::user()->email); ?>" required>
                    <button type="submit" class="btn btn-primary-lp">Send Test</button>
                </div>
                <div class="form-text" style="font-size: 0.725rem;">Renders safe dummy variables with real unsubscribe links.</div>
            </form>
        </div>
    </div>

    <!-- Campaign Template Details -->
    <div class="col-lg-6">
        <div class="card-lp p-4 h-100">
            <div class="d-flex justify-content-between align-items-center mb-2">
                <h6 class="fw-bold mb-0"><i class="bi bi-file-text text-info me-1"></i> Template Preview</h6>
                <span class="badge bg-light text-dark border"><?php echo e($campaign->template?->name ?? 'Standard Template'); ?></span>
            </div>
            <div class="small fw-semibold text-dark mb-1">Subject Formula:</div>
            <div class="small text-muted p-2 bg-light rounded border mb-2 font-monospace">
                <?php echo e($campaign->template?->subject); ?>

            </div>
        </div>
    </div>
</div>

<!-- Enrolled Prospects & Queue Table -->
<div class="card-lp overflow-hidden mb-4">
    <div class="p-3 border-bottom d-flex justify-content-between align-items-center bg-light-subtle">
        <h6 class="fw-bold mb-0">Enrolled Prospects & Outreach Drafts (<?php echo e($recipients->total()); ?>)</h6>
        <span class="small text-muted">Suppressed emails are automatically excluded</span>
    </div>

    <div class="table-responsive">
        <table class="table table-lp align-middle">
            <thead>
                <tr>
                    <th>Prospect</th>
                    <th>Personalized Subject</th>
                    <th class="text-center">Status</th>
                    <th>Scheduled / Sent</th>
                    <th class="text-end">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $recipients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <tr>
                    <td>
                        <a href="<?php echo e(route('leads.show', $rec->lead)); ?>" class="fw-bold text-dark text-decoration-none">
                            <?php echo e($rec->lead->full_name); ?>

                        </a>
                        <div class="small text-muted"><?php echo e($rec->lead->email); ?> • <?php echo e($rec->lead->company?->name ?? 'Direct'); ?></div>
                    </td>

                    <td>
                        <div class="small fw-semibold text-dark"><?php echo e($rec->personalized_subject); ?></div>
                        <div class="small text-muted text-truncate" style="max-width: 380px;"><?php echo e(Str::limit($rec->personalized_body, 80)); ?></div>
                    </td>

                    <td class="text-center">
                        <span class="badge <?php echo e($rec->status === 'delivered' ? 'bg-success' : ($rec->status === 'sent' ? 'bg-primary' : ($rec->status === 'replied' ? 'bg-purple' : ($rec->status === 'bounced' ? 'bg-danger' : ($rec->status === 'approved' ? 'bg-info text-dark' : 'bg-light text-secondary border'))))); ?>">
                            <?php echo e(ucfirst($rec->status)); ?>

                        </span>
                    </td>

                    <td class="small text-muted">
                        <?php echo e($rec->sent_at ? $rec->sent_at->format('M d, Y H:i') : ($rec->scheduled_at ? 'Queued ' . $rec->scheduled_at->diffForHumans() : 'Draft')); ?>

                    </td>

                    <td class="text-end">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(in_array($rec->status, ['draft', 'approved', 'queued'])): ?>
                        <form action="<?php echo e(route('campaigns.recipient.dispatch', $rec)); ?>" method="POST" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-sm btn-outline-primary py-0 px-2" title="Dispatch now via configured mailer">
                                <i class="bi bi-send me-1"></i> Send Now
                            </button>
                        </form>
                        <?php else: ?>
                        <span class="text-muted small"><i class="bi bi-check-all text-primary"></i> Processed</span>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </td>
                </tr>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                <tr>
                    <td colspan="5" class="text-center py-4 text-muted">No recipients found for this campaign.</td>
                </tr>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($recipients->hasPages()): ?>
    <div class="p-3 border-top bg-light-subtle d-flex justify-content-end">
        <?php echo e($recipients->links()); ?>

    </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Leed_generation\resources\views/campaigns/show.blade.php ENDPATH**/ ?>