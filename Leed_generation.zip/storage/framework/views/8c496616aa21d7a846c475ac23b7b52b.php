<?php $__env->startSection('title', 'Edit ' . $lead->full_name); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-lg-8">
        <div class="mb-4">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-2" style="font-size: 0.825rem;">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('leads.index')); ?>">Leads</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('leads.show', $lead)); ?>"><?php echo e($lead->full_name); ?></a></li>
                    <li class="breadcrumb-item active">Edit</li>
                </ol>
            </nav>
            <h3 class="fw-bold mb-1">Edit Prospect Information</h3>
        </div>

        <div class="card-lp p-4">
            <form action="<?php echo e(route('leads.update', $lead)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="row g-3 mb-3">
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">Full Name <span class="text-danger">*</span></label>
                        <input type="text" name="full_name" class="form-control" value="<?php echo e(old('full_name', $lead->full_name)); ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">Job Title</label>
                        <input type="text" name="job_title" class="form-control" value="<?php echo e(old('job_title', $lead->job_title)); ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">Business Email</label>
                        <input type="email" name="email" class="form-control" value="<?php echo e(old('email', $lead->email)); ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">Phone Number</label>
                        <input type="text" name="phone" class="form-control" value="<?php echo e(old('phone', $lead->phone)); ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">Company</label>
                        <select name="company_id" class="form-select">
                            <option value="">Unassigned</option>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                <option value="<?php echo e($comp->id); ?>" <?php echo e(old('company_id', $lead->company_id) == $comp->id ? 'selected' : ''); ?>>
                                    <?php echo e($comp->name); ?>

                                </option>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">Lifecycle Stage</label>
                        <select name="lifecycle_stage" class="form-select">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = [
                                'new' => 'New',
                                'researching' => 'Researching',
                                'qualified' => 'Qualified',
                                'ready_for_review' => 'Ready for Review',
                                'approved' => 'Approved for Outreach',
                                'contacted' => 'Contacted',
                                'replied' => 'Replied',
                                'interested' => 'Interested',
                                'meeting_booked' => 'Meeting Booked',
                                'proposal_sent' => 'Proposal Sent',
                                'negotiation' => 'Negotiation',
                                'won' => 'Won Deal',
                                'lost' => 'Lost Deal',
                                'not_a_fit' => 'Not a Fit / Suppressed'
                            ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stgKey => $stgLabel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                <option value="<?php echo e($stgKey); ?>" <?php echo e(old('lifecycle_stage', $lead->lifecycle_stage) == $stgKey ? 'selected' : ''); ?>><?php echo e($stgLabel); ?></option>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">Assigned Representative</label>
                        <select name="assigned_user_id" class="form-select">
                            <option value="">Unassigned</option>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $salesReps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                <option value="<?php echo e($rep->id); ?>" <?php echo e(old('assigned_user_id', $lead->assigned_user_id) == $rep->id ? 'selected' : ''); ?>>
                                    <?php echo e($rep->name); ?>

                                </option>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">Next Action Date</label>
                        <input type="date" name="next_action_date" class="form-control" value="<?php echo e(old('next_action_date', $lead->next_action_date?->format('Y-m-d'))); ?>">
                    </div>
                    <div class="col-12">
                        <label class="form-label small fw-semibold">Next Action Note</label>
                        <input type="text" name="next_action_note" class="form-control" value="<?php echo e(old('next_action_note', $lead->next_action_note)); ?>" placeholder="e.g. Follow up on proposal milestones">
                    </div>
                    <div class="col-12">
                        <label class="form-label small fw-semibold">Notes</label>
                        <textarea name="notes" rows="3" class="form-control"><?php echo e(old('notes', $lead->notes)); ?></textarea>
                    </div>
                </div>

                <div class="d-flex justify-content-end gap-2 pt-3 border-top">
                    <a href="<?php echo e(route('leads.show', $lead)); ?>" class="btn btn-light border px-4">Cancel</a>
                    <button type="submit" class="btn btn-primary-lp px-4">Update Lead</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Leed_generation\resources\views/leads/edit.blade.php ENDPATH**/ ?>