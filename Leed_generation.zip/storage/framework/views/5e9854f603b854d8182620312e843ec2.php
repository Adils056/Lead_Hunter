<?php $__env->startSection('title', 'Sales Assistant — ' . ($lead->company?->name ?? $lead->full_name)); ?>
<?php $__env->startSection('content'); ?>
<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
    <div>
        <nav><ol class="breadcrumb mb-1 small"><li class="breadcrumb-item"><a href="<?php echo e(route('leads.index')); ?>">Leads</a></li><li class="breadcrumb-item"><a href="<?php echo e(route('leads.show', $lead)); ?>"><?php echo e($lead->full_name); ?></a></li><li class="breadcrumb-item active">Sales Assistant</li></ol></nav>
        <h3 class="fw-bold mb-0"><?php echo e($lead->company?->name ?? $lead->full_name); ?></h3>
        <div class="small text-muted">Score <?php echo e($lead->overall_score); ?>/100 (<?php echo e($lead->score_breakdown['confidence'] ?? 'n/a'); ?> confidence) · contact: <?php echo e(str_replace('_', ' ', $lead->contact_status)); ?> · <?php echo e($lead->email ?: 'no email'); ?> <?php echo e($lead->phone ? '· ' . $lead->phone : ''); ?></div>
    </div>
    <div class="d-flex gap-2">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($lead->company && ($lead->company->website || $lead->company->domain)): ?>
        <form method="POST" action="<?php echo e(route('companies.audit', $lead->company)); ?>"><?php echo csrf_field(); ?><button class="btn btn-sm btn-outline-success"><i class="bi bi-clipboard2-pulse"></i> <?php echo e($lead->company->website_audited_at ? 'Re-audit website' : 'Audit website'); ?></button></form>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <form method="POST" action="<?php echo e(route('leads.rescore', $lead)); ?>"><?php echo csrf_field(); ?><button class="btn btn-sm btn-outline-primary"><i class="bi bi-arrow-repeat"></i> Re-score</button></form>
    </div>
</div>

<div class="row g-4">
    <div class="col-lg-7">
        
        <div class="card-lp p-4 mb-4">
            <h6 class="fw-bold"><span class="badge bg-primary me-1">1</span> What to offer</h6>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($offer['offer']): ?>
                <div class="fs-5 fw-bold"><?php echo e($offer['offer']['label']); ?> <span class="small text-muted fw-normal">typical $<?php echo e(number_format($offer['offer']['typical_value_usd'][0])); ?>–<?php echo e(number_format($offer['offer']['typical_value_usd'][1])); ?> (your catalog estimate)</span></div>
                <p class="small mb-2"><?php echo e($offer['why']); ?></p>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($offer['alternatives']): ?><div class="small text-muted">Also relevant: <?php echo e(collect($offer['alternatives'])->pluck('label')->implode(', ')); ?></div><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <?php else: ?>
                <p class="small text-muted mb-0"><?php echo e($offer['why']); ?></p>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>

        
        <div class="card-lp p-4 mb-4">
            <h6 class="fw-bold"><span class="badge bg-primary me-1">2</span> First email (evidence-only)</h6>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($email['ok']): ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $email['warnings']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?><div class="alert alert-warning py-1 px-2 small mb-2"><?php echo e($w); ?></div><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                <label class="small fw-semibold">Subject</label>
                <input class="form-control form-control-sm mb-2" value="<?php echo e($email['draft']['subject']); ?>" id="subj">
                <label class="small fw-semibold">Body <span class="text-muted fw-normal">(<?php echo e($email['draft']['word_count']); ?> words · <?php echo e($email['draft']['generator']); ?> · limit <?php echo e(config('leadpilot.outreach.max_words_first_email')); ?>)</span></label>
                <textarea class="form-control form-control-sm mb-2" rows="9" id="body"><?php echo e($email['draft']['body']); ?></textarea>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($aiAvailable): ?>
                <form method="POST" action="<?php echo e(route('assistant.polish', $lead)); ?>" class="d-inline"><?php echo csrf_field(); ?><button class="btn btn-sm btn-outline-primary"><i class="bi bi-stars"></i> Polish with AI (facts-only)</button></form>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <button type="button" class="btn btn-sm btn-outline-secondary" onclick="navigator.clipboard.writeText(document.getElementById('subj').value+'\n\n'+document.getElementById('body').value);this.innerText='Copied'">Copy</button>
                <div class="small text-muted mt-3"><strong>Facts used</strong> (each verifiable):
                    <ul class="ps-3 mb-0"><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $email['facts_used']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?><li><?php echo e(ucfirst($f['text'])); ?> <span class="text-muted">— <?php echo e($f['source']); ?>, <?php echo e($f['observed']); ?></span></li><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?></ul></div>
            <?php else: ?>
                <p class="small text-muted mb-0"><?php echo e($email['reason']); ?></p>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>

        
        <div class="card-lp p-4 mb-4">
            <h6 class="fw-bold"><span class="badge bg-primary me-1">3</span> Follow-up</h6>
            <p class="small mb-2"><?php echo e($followUp['message']); ?></p>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($followUp['draft'])): ?><textarea class="form-control form-control-sm" rows="6"><?php echo e($followUp['draft']); ?></textarea><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <div class="small text-muted mt-2">Cadence: touches at +<?php echo e(implode(', +', config('leadpilot.outreach.follow_up_days'))); ?> days, max <?php echo e(config('leadpilot.outreach.max_touches')); ?>; stops on any reply.</div>
        </div>

        
        <div class="card-lp p-4">
            <h6 class="fw-bold"><span class="badge bg-primary me-1">4</span> They replied? Paste it here</h6>
            <form method="POST" action="<?php echo e(route('assistant.classify', $lead)); ?>"><?php echo csrf_field(); ?>
                <textarea name="reply" class="form-control form-control-sm mb-2" rows="4" placeholder="Paste the prospect's reply…"><?php echo e($replyText); ?></textarea>
                <button class="btn btn-sm btn-primary-lp">Classify & suggest response</button>
            </form>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($classification): ?>
                <?php $cc = ['interested'=>'bg-success','not_interested'=>'bg-secondary','referral'=>'bg-info text-dark','objection'=>'bg-warning text-dark','out_of_office'=>'bg-light text-dark border','unsubscribe'=>'bg-danger','uncertain'=>'bg-dark']; ?>
                <div class="mt-3 p-3 border rounded">
                    <span class="badge <?php echo e($cc[$classification['category']] ?? 'bg-dark'); ?>"><?php echo e(str_replace('_', ' ', $classification['category'])); ?><?php echo e(!empty($classification['subtype']) && $classification['subtype'] === 'meeting_request' ? ' · meeting request' : ''); ?><?php echo e(!empty($classification['objection_type']) ? ' · ' . $classification['objection_type'] : ''); ?></span>
                    <span class="small text-muted"><?php echo e($classification['confidence']); ?>% · <?php echo e($classification['requires_human_review'] ? 'human review' : 'safe to automate'); ?></span>
                    <p class="small mt-2 mb-2"><?php echo e($classification['reasoning']); ?></p>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($classification['referred_email'])): ?><p class="small">Referred to: <strong><?php echo e($classification['referred_email']); ?></strong></p><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($classification['suggested_reply']): ?><textarea class="form-control form-control-sm" rows="5"><?php echo e($classification['suggested_reply']); ?></textarea><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>

    <div class="col-lg-5">
        <div class="card-lp p-4 mb-4">
            <h6 class="fw-bold mb-3">Why this lead (score evidence)</h6>
            <?php echo $__env->make('leads._score_panel', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
        <div class="card-lp p-4 mb-4">
            <h6 class="fw-bold mb-2">All verified observations</h6>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $facts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <div class="small py-1 border-bottom"><?php echo e(ucfirst($f['text'])); ?>.<div class="text-muted" style="font-size:.72rem"><?php echo e($f['source']); ?> · <?php echo e($f['observed']); ?></div></div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?> <p class="small text-muted mb-0">None yet.</p> <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
        <div class="card-lp p-4">
            <h6 class="fw-bold mb-2">Discovery-call questions (BANT)</h6>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $qs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <div class="small fw-semibold text-uppercase text-muted mt-2"><?php echo e($k); ?></div>
                <ul class="small ps-3 mb-0"><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $qs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?><li><?php echo e($q); ?></li><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?></ul>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Leed_generation\resources\views/assistant/show.blade.php ENDPATH**/ ?>