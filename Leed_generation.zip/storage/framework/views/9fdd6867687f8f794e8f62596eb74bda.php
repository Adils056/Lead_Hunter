<?php $__env->startSection('title', 'Edit ' . $company->name); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-lg-8">
        <div class="mb-4">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-2" style="font-size: 0.825rem;">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('companies.index')); ?>">Companies</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('companies.show', $company)); ?>"><?php echo e($company->name); ?></a></li>
                    <li class="breadcrumb-item active">Edit</li>
                </ol>
            </nav>
            <h3 class="fw-bold mb-1">Edit Company Details</h3>
        </div>

        <div class="card-lp p-4">
            <form action="<?php echo e(route('companies.update', $company)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="row g-3 mb-3">
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">Company Name <span class="text-danger">*</span></label>
                        <input type="text" name="name" class="form-control" value="<?php echo e(old('name', $company->name)); ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">Website URL</label>
                        <input type="url" name="website" class="form-control" value="<?php echo e(old('website', $company->website)); ?>">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label small fw-semibold">Country <span class="text-danger">*</span></label>
                        <input type="text" name="country" class="form-control" value="<?php echo e(old('country', $company->country)); ?>" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label small fw-semibold">City</label>
                        <input type="text" name="city" class="form-control" value="<?php echo e(old('city', $company->city)); ?>">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label small fw-semibold">Lifecycle Status</label>
                        <select name="status" class="form-select">
                            <option value="prospect" <?php echo e(old('status', $company->status) == 'prospect' ? 'selected' : ''); ?>>Prospect</option>
                            <option value="active" <?php echo e(old('status', $company->status) == 'active' ? 'selected' : ''); ?>>Active Account</option>
                            <option value="customer" <?php echo e(old('status', $company->status) == 'customer' ? 'selected' : ''); ?>>Paying Customer</option>
                            <option value="archived" <?php echo e(old('status', $company->status) == 'archived' ? 'selected' : ''); ?>>Archived</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">Company Size</label>
                        <select name="size_range" class="form-select">
                            <option value="">Select range...</option>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = ['1-10', '11-50', '51-200', '201-500', '500+']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                <option value="<?php echo e($sz); ?>" <?php echo e(old('size_range', $company->size_range) == $sz ? 'selected' : ''); ?>><?php echo e($sz); ?> employees</option>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">Assigned Sales Representative</label>
                        <select name="assigned_user_id" class="form-select">
                            <option value="">Unassigned</option>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $salesReps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                <option value="<?php echo e($rep->id); ?>" <?php echo e(old('assigned_user_id', $company->assigned_user_id) == $rep->id ? 'selected' : ''); ?>><?php echo e($rep->name); ?></option>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">Industry</label>
                        <input type="text" name="industry" class="form-control" value="<?php echo e(old('industry', $company->industry)); ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">Public Email</label>
                        <input type="email" name="public_email" class="form-control" value="<?php echo e(old('public_email', $company->public_email)); ?>">
                    </div>
                    <div class="col-12">
                        <label class="form-label small fw-semibold">Technology Stack (Comma separated)</label>
                        <input type="text" name="tech_stack" class="form-control" value="<?php echo e(old('tech_stack', is_array($company->tech_stack) ? implode(', ', $company->tech_stack) : '')); ?>">
                    </div>
                    <div class="col-12">
                        <label class="form-label small fw-semibold">Business Description</label>
                        <textarea name="description" rows="3" class="form-control"><?php echo e(old('description', $company->description)); ?></textarea>
                    </div>
                    <div class="col-12">
                        <label class="form-label small fw-semibold">Internal Rep Notes</label>
                        <textarea name="notes" rows="2" class="form-control"><?php echo e(old('notes', $company->notes)); ?></textarea>
                    </div>
                </div>

                <div class="d-flex justify-content-end gap-2 pt-3 border-top">
                    <a href="<?php echo e(route('companies.show', $company)); ?>" class="btn btn-light border px-4">Cancel</a>
                    <button type="submit" class="btn btn-primary-lp px-4">Update Company</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Leed_generation\resources\views/companies/edit.blade.php ENDPATH**/ ?>