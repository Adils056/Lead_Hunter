<?php $__env->startSection('title', 'Win Ladder'); ?>

<?php $__env->startSection('content'); ?>
<?php ($tiers = \App\Services\Outreach\WinLadderService::TIERS); ?>
<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
    <div>
        <h3 class="fw-bold mb-1">Win Ladder — who to email first</h3>
        <p class="text-muted small mb-0">
            Every lead sits on one rung. Rung A is ranked best-first by buying evidence: an explicit request beats an audited website gap, which beats a generic fit.
            Evidence points are not a win probability — but each rung tells you the one next action.
        </p>
    </div>
    <div class="d-flex gap-2">
        <a href="<?php echo e(route('leads.win-ladder.export', ['tier' => $tier])); ?>" class="btn btn-sm btn-outline-secondary d-flex align-items-center gap-1">
            <i class="bi bi-download"></i><span>Export rung <?php echo e($tier); ?> (CSV)</span>
        </a>
        <form method="POST" action="<?php echo e(route('leads.win-ladder.refresh')); ?>">
            <?php echo csrf_field(); ?>
            <button class="btn btn-sm btn-primary-lp d-flex align-items-center gap-1" type="submit">
                <i class="bi bi-arrow-repeat"></i><span>Recompute ladder</span>
            </button>
        </form>
    </div>
</div>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success')): ?>
    <div class="alert alert-success py-2"><?php echo e(session('success')); ?></div>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

<div class="row g-2 mb-4">
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = \App\Services\Outreach\WinLadderService::ORDER; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
        <div class="col-6 col-md-4 col-xl-2">
            <a href="<?php echo e(route('leads.win-ladder', ['tier' => $t])); ?>" class="text-decoration-none">
                <div class="card-lp p-3 h-100 <?php echo e($tier === $t ? 'border border-2 border-' . $tiers[$t]['class'] : ''); ?>">
                    <div class="d-flex justify-content-between align-items-start">
                        <span class="badge bg-<?php echo e($tiers[$t]['class']); ?><?php echo e(in_array($tiers[$t]['class'], ['warning','info']) ? ' text-dark' : ''); ?>"><i class="bi <?php echo e($tiers[$t]['icon']); ?> me-1"></i><?php echo e($t); ?></span>
                        <span class="fs-4 fw-bold text-dark"><?php echo e($counts[$t] ?? 0); ?></span>
                    </div>
                    <div class="fw-semibold text-dark mt-2"><?php echo e($tiers[$t]['short']); ?></div>
                    <div class="text-muted" style="font-size: .72rem;"><?php echo e($tiers[$t]['help']); ?></div>
                </div>
            </a>
        </div>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
</div>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($unranked > 0): ?>
    <div class="alert alert-warning py-2 small"><?php echo e($unranked); ?> lead(s) are not ranked yet — click <strong>Recompute ladder</strong>.</div>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

<div class="card-lp overflow-hidden">
    <div class="px-3 py-2 border-bottom d-flex justify-content-between align-items-center">
        <div>
            <span class="badge bg-<?php echo e($tiers[$tier]['class']); ?><?php echo e(in_array($tiers[$tier]['class'], ['warning','info']) ? ' text-dark' : ''); ?> me-2"><?php echo e($tier); ?></span>
            <strong><?php echo e($tiers[$tier]['label']); ?></strong>
            <span class="text-muted small ms-2"><?php echo e($tiers[$tier]['help']); ?></span>
        </div>
        <span class="text-muted small"><?php echo e($leads->total()); ?> lead(s), best first</span>
    </div>
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
                <tr>
                    <th style="width:3rem">#</th>
                    <th>Company &amp; contact</th>
                    <th>Reach</th>
                    <th>Score / points</th>
                    <th>Why this rung (evidence)</th>
                    <th><?php echo e($tier === 'A' ? 'Next action' : 'Blocker → next action'); ?></th>
                    <th class="text-end">Act</th>
                </tr>
            </thead>
            <tbody>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <tr>
                    <td class="text-muted fw-bold"><?php echo e($leads->firstItem() + $i); ?></td>
                    <td>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($lead->company): ?>
                            <a href="<?php echo e(route('companies.show', $lead->company)); ?>" class="fw-bold text-dark text-decoration-none"><?php echo e($lead->company->name); ?></a>
                        <?php else: ?>
                            <span class="fw-bold text-dark">Independent</span>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        <div class="small">
                            <a href="<?php echo e(route('leads.show', $lead)); ?>" class="text-decoration-none"><?php echo e($lead->full_name); ?></a>
                            <span class="text-muted">· <?php echo e($lead->job_title ?: 'role unknown'); ?></span>
                        </div>
                        <div class="text-muted" style="font-size:.72rem"><?php echo e($lead->company?->city); ?> <?php echo e($lead->country); ?> <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($lead->icpProfile): ?>· ICP: <?php echo e($lead->icpProfile->name); ?><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?></div>
                    </td>
                    <td class="small">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($lead->email): ?>
                            <div><?php echo e($lead->email); ?></div>
                            <span class="badge <?php echo e($lead->email_verification_status === 'verified' ? 'bg-success-subtle text-success' : (in_array($lead->email_verification_status, ['risky','catch_all']) ? 'bg-warning-subtle text-warning' : ($lead->email_verification_status === 'invalid' ? 'bg-danger-subtle text-danger' : 'bg-secondary-subtle text-secondary'))); ?>" style="font-size:.7rem"><?php echo e(ucfirst($lead->email_verification_status)); ?></span>
                            <span class="badge bg-light text-dark border" style="font-size:.7rem"><?php echo e(str_replace('_', ' ', $lead->contact_status ?? 'identified')); ?></span>
                        <?php else: ?>
                            <span class="text-muted">No email</span>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </td>
                    <td>
                        <span class="badge-lp <?php echo e(\App\Support\ScoreBands::badgeClass($lead->overall_score)); ?>"><?php echo e($lead->overall_score); ?> / 100</span>
                        <div class="small text-muted mt-1" title="Evidence points (ranking only)"><i class="bi bi-trophy me-1"></i><?php echo e($lead->win_points); ?> pts</div>
                    </td>
                    <td class="small">
                        <ul class="mb-0 ps-3">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = array_slice((array) $lead->win_reasons, 0, 4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                <li><?php echo e($r); ?></li>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        </ul>
                    </td>
                    <td class="small">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = (array) $lead->win_blockers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <div class="text-<?php echo e($tier === 'D' ? 'danger' : 'warning-emphasis'); ?>"><i class="bi bi-exclamation-triangle me-1"></i><?php echo e($b); ?></div>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        <div class="<?php echo e($lead->win_blockers ? 'text-muted' : 'fw-semibold text-success'); ?>"><?php echo e($lead->win_next_action); ?></div>
                    </td>
                    <td class="text-end">
                        <div class="btn-group btn-group-sm">
                            <a href="<?php echo e(route('assistant.show', $lead)); ?>" class="btn btn-light border" title="Sales Assistant: evidence-based draft"><i class="bi bi-magic text-primary"></i></a>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($lead->email && !in_array($lead->email_verification_status, ['verified'])): ?>
                                <form action="<?php echo e(route('leads.verify-email', $lead)); ?>" method="POST" class="d-inline"><?php echo csrf_field(); ?>
                                    <button class="btn btn-light border" title="Verify email"><i class="bi bi-patch-check"></i></button>
                                </form>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            <form action="<?php echo e(route('leads.rescore', $lead)); ?>" method="POST" class="d-inline"><?php echo csrf_field(); ?>
                                <button class="btn btn-light border" title="Re-score and re-rank"><i class="bi bi-arrow-repeat"></i></button>
                            </form>
                            <a href="<?php echo e(route('leads.show', $lead)); ?>" class="btn btn-light border" title="Open lead"><i class="bi bi-eye"></i></a>
                        </div>
                    </td>
                </tr>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                <tr><td colspan="7" class="text-center text-muted py-5">No leads on this rung.</td></tr>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($leads->hasPages()): ?>
        <div class="px-3 py-2 border-top"><?php echo e($leads->links()); ?></div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</div>

<div class="card-lp p-3 mt-4 small text-muted">
    <strong class="text-dark">How the ladder decides (top rule wins):</strong>
    <ol class="mb-1 mt-1">
        <li><strong>R Replied</strong> — any reply that is not a decline or an out-of-office, or stage replied / meeting / proposal. A human answers.</li>
        <li><strong>D Do not email</strong> — suppression list, declined, invalid address, country not approved, ICP exclusion, won/lost/not a fit.</li>
        <li><strong>S In sequence</strong> — draft pending approval or scheduled, or the follow-up interval has not passed.</li>
        <li><strong>C Nurture</strong> — no email, no named contact, sequence exhausted, score below nurture, or more than two blockers.</li>
        <li><strong>A Email now</strong> — all 10 eligibility checks pass, there is a dated observation to personalise with, and the best-fit service is approved.</li>
        <li><strong>B One fix away</strong> — everything else: exactly the listed blocker(s) stand between this lead and rung A.</li>
    </ol>
    Points inside a rung: explicit request up to 400 · software need 150 · website audit gap 2× opportunity score · decision maker 150 (influencer 80) · verified email 100 (risky 40) · approved offer 80 · lead score up to 100 · fresh evidence 60 · active business 30 · phone 10.
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Leed_generation\resources\views/leads/win_ladder.blade.php ENDPATH**/ ?>