<?php $__env->startSection('title', 'Lead Scoring Settings'); ?>
<?php $__env->startSection('content'); ?>
<?php
    $labels = ['explicit_request' => 'Explicit project / RFP / enquiry', 'software_need' => 'Active software need', 'website_gap' => 'Website gaps (audit)', 'growth_initiative' => 'Growth / activity', 'icp_match' => 'ICP match', 'contact_role' => 'Decision-maker reachable', 'service_fit' => 'Service fit', 'contact_verification' => 'Contact verification', 'data_completeness' => 'Data completeness', 'signal_freshness' => 'Evidence freshness'];
    $w = old('weights', $effective['weights']); $t = old('thresholds', $effective['thresholds']);
?>
<div class="mb-4">
    <h3 class="fw-bold mb-1">Lead Scoring</h3>
    <p class="text-muted small mb-0">Weights are points out of 100. The score is a <strong>heuristic ranking</strong>; the calibration panel shows whether it actually predicts replies and deals.</p>
</div>
<div class="row g-4">
    <div class="col-lg-6">
        <form method="POST" action="<?php echo e(route('settings.scoring.update')); ?>" class="card-lp p-4">
            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
            <h6 class="fw-bold">Factor weights <span class="small text-muted fw-normal">(must total 100 — now <span id="tot"><?php echo e(array_sum($w)); ?></span>)</span></h6>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $effective['weights']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $_): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <div class="d-flex align-items-center gap-2 mb-2">
                    <label class="small flex-grow-1"><?php echo e($labels[$k] ?? $k); ?> <span class="text-muted">(default <?php echo e($defaults['weights'][$k]); ?>)</span></label>
                    <input type="number" min="0" max="100" name="weights[<?php echo e($k); ?>]" value="<?php echo e($w[$k]); ?>" class="form-control form-control-sm w-25 wt">
                </div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            <h6 class="fw-bold mt-4">Thresholds</h6>
            <div class="row g-2">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = ['high' => 'High priority ≥', 'qualified' => 'Qualified ≥', 'nurture' => 'Nurture ≥']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <div class="col-4"><label class="small"><?php echo e($l); ?></label><input type="number" min="0" max="100" name="thresholds[<?php echo e($k); ?>]" value="<?php echo e($t[$k]); ?>" class="form-control form-control-sm"></div>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </div>
            <div class="form-check mt-3"><input class="form-check-input" type="checkbox" name="rescore" value="1" id="rs" checked><label class="form-check-label small" for="rs">Re-score all leads after saving</label></div>
            <button class="btn btn-primary-lp mt-3">Save</button>
        </form>
    </div>
    <div class="col-lg-6">
        <div class="card-lp p-4">
            <h6 class="fw-bold">Does the score predict outcomes?</h6>
            <div class="alert <?php echo e($calibration['sufficient'] ? (($calibration['auc'] ?? 0) >= 0.7 ? 'alert-success' : 'alert-warning') : 'alert-secondary'); ?> small"><?php echo e($calibration['verdict']); ?></div>
            <table class="table table-sm small">
                <thead><tr class="text-muted"><th>Score band</th><th>Resolved leads</th><th>Positive</th><th>Positive rate</th></tr></thead>
                <tbody><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $calibration['bands']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?><tr><td><?php echo e($b['band']); ?></td><td><?php echo e($b['n']); ?></td><td><?php echo e($b['positives']); ?></td><td><?php echo e($b['rate'] !== null ? $b['rate'] . '%' : '—'); ?></td></tr><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?></tbody>
            </table>
            <div class="small text-muted">AUC <?php echo e($calibration['auc'] ?? '—'); ?> (0.5 = random, 1 = perfect) · Brier <?php echo e($calibration['brier'] ?? '—'); ?> · n=<?php echo e($calibration['n']); ?>.<br>
                Positive = interested/meeting/proposal/won or a positive reply. Negative = lost/not a fit or no positive outcome 21+ days after contact. Uses the score recorded before first contact.</div>
        </div>
    </div>
</div>
<script>document.querySelectorAll('.wt').forEach(i=>i.addEventListener('input',()=>{let s=0;document.querySelectorAll('.wt').forEach(x=>s+=+x.value||0);const t=document.getElementById('tot');t.innerText=s;t.className=s===100?'text-success':'text-danger';}));</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Leed_generation\resources\views/settings/scoring.blade.php ENDPATH**/ ?>