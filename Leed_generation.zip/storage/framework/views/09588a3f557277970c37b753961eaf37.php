<?php $__env->startSection('title', 'Add Company'); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-lg-8">
        <div class="mb-4">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-2" style="font-size: 0.825rem;">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('companies.index')); ?>">Companies</a></li>
                    <li class="breadcrumb-item active">Add Company</li>
                </ol>
            </nav>
            <h3 class="fw-bold mb-1">Add New Company</h3>
            <p class="text-muted small">Enter business details. Domain normalization and duplicate detection are applied automatically.</p>
        </div>

        <div class="card-lp p-4">
            <form action="<?php echo e(route('companies.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="row g-3 mb-3">
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">Company Name <span class="text-danger">*</span></label>
                        <input type="text" name="name" class="form-control" value="<?php echo e(old('name')); ?>" placeholder="e.g. Stripe Inc" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">Website URL</label>
                        <input type="url" name="website" class="form-control" value="<?php echo e(old('website')); ?>" placeholder="https://example.com">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label small fw-semibold">Country <span class="text-danger">*</span></label>
                        <input type="text" name="country" class="form-control" value="<?php echo e(old('country', 'United States')); ?>" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label small fw-semibold">City</label>
                        <input type="text" name="city" class="form-control" value="<?php echo e(old('city')); ?>" placeholder="e.g. Austin, TX">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label small fw-semibold">Company Size</label>
                        <select name="size_range" class="form-select">
                            <option value="">Select range...</option>
                            <option value="1-10">1-10 employees</option>
                            <option value="11-50">11-50 employees</option>
                            <option value="51-200">51-200 employees</option>
                            <option value="201-500">201-500 employees</option>
                            <option value="500+">500+ employees</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">Industry</label>
                        <input type="text" name="industry" class="form-control" value="<?php echo e(old('industry')); ?>" placeholder="e.g. Financial Technology">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">Assigned Sales Representative</label>
                        <select name="assigned_user_id" class="form-select">
                            <option value="">Unassigned</option>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $salesReps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                <option value="<?php echo e($rep->id); ?>" <?php echo e(old('assigned_user_id', Auth::id()) == $rep->id ? 'selected' : ''); ?>><?php echo e($rep->name); ?> (<?php echo e(ucfirst($rep->role)); ?>)</option>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">Public Business Email</label>
                        <input type="email" name="public_email" class="form-control" value="<?php echo e(old('public_email')); ?>" placeholder="contact@example.com">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">Public Business Phone</label>
                        <input type="text" name="public_phone" class="form-control" value="<?php echo e(old('public_phone')); ?>" placeholder="+1 (555) 000-0000">
                    </div>
                    <div class="col-12">
                        <label class="form-label small fw-semibold">Technology Stack (Comma separated)</label>
                        <input type="text" name="tech_stack" class="form-control" value="<?php echo e(old('tech_stack')); ?>" placeholder="Laravel, PHP, Vue.js, MySQL, AWS">
                    </div>
                    <div class="col-12">
                        <label class="form-label small fw-semibold">Business Description / Discovery Notes</label>
                        <textarea name="description" rows="3" class="form-control" placeholder="Overview of business model, services offered, and observed software opportunities..."><?php echo e(old('description')); ?></textarea>
                    </div>
                </div>

                <div class="d-flex justify-content-end gap-2 pt-3 border-top">
                    <a href="<?php echo e(route('companies.index')); ?>" class="btn btn-light border px-4">Cancel</a>
                    <button type="submit" class="btn btn-primary-lp px-4">Save Company</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Leed_generation\resources\views/companies/create.blade.php ENDPATH**/ ?>