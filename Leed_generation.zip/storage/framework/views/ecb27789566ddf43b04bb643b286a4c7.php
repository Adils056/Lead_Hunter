<?php $__env->startSection('title', 'Lead Intelligence'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
    <div>
        <h3 class="fw-bold mb-1">Lead Intelligence Directory</h3>
        <p class="text-muted small mb-0">Verified business prospects scored by transparent 100-point AI & intent models.</p>
    </div>

    <div class="d-flex gap-2">
        <a href="<?php echo e(route('leads.export')); ?>" class="btn btn-sm btn-outline-secondary d-flex align-items-center gap-1">
            <i class="bi bi-download"></i>
            <span>Export CSV</span>
        </a>
        <a href="<?php echo e(route('leads.import')); ?>" class="btn btn-sm btn-outline-secondary d-flex align-items-center gap-1">
            <i class="bi bi-upload"></i>
            <span>Import CSV</span>
        </a>
        <a href="<?php echo e(route('leads.create')); ?>" class="btn btn-sm btn-primary-lp d-flex align-items-center gap-1">
            <i class="bi bi-plus-lg"></i>
            <span>Add Prospect</span>
        </a>
    </div>
</div>

<!-- Advanced Filter Bar -->
<div class="card-lp p-3 mb-4">
    <form action="<?php echo e(route('leads.index')); ?>" method="GET" class="row g-2 align-items-center">
        <div class="col-md-3">
            <div class="input-group input-group-sm">
                <span class="input-group-text bg-light border-end-0 text-muted"><i class="bi bi-search"></i></span>
                <input type="text" name="search" class="form-control border-start-0" placeholder="Search name, email, job title..." value="<?php echo e($search); ?>">
            </div>
        </div>

        <div class="col-md-2">
            <select name="stage" class="form-select form-select-sm" onchange="this.form.submit()">
                <option value="">All Lifecycle Stages</option>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = ['new' => 'New', 'researching' => 'Researching', 'qualified' => 'Qualified', 'ready_for_review' => 'Ready for Review', 'contacted' => 'Contacted', 'replied' => 'Replied', 'meeting_booked' => 'Meeting Booked', 'proposal_sent' => 'Proposal Sent', 'won' => 'Won Deal', 'lost' => 'Lost Deal']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stgKey => $stgLabel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <option value="<?php echo e($stgKey); ?>" <?php echo e($stage == $stgKey ? 'selected' : ''); ?>><?php echo e($stgLabel); ?></option>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </select>
        </div>

        <div class="col-md-2">
            <select name="country" class="form-select form-select-sm" onchange="this.form.submit()">
                <option value="">All Countries</option>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <option value="<?php echo e($c); ?>" <?php echo e($country == $c ? 'selected' : ''); ?>><?php echo e($c); ?></option>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </select>
        </div>

        <div class="col-md-2">
            <select name="verification" class="form-select form-select-sm" onchange="this.form.submit()">
                <option value="">All Verification States</option>
                <option value="verified" <?php echo e($verification == 'verified' ? 'selected' : ''); ?>>Verified Only</option>
                <option value="risky" <?php echo e($verification == 'risky' ? 'selected' : ''); ?>>Risky / Catch-all</option>
                <option value="unverified" <?php echo e($verification == 'unverified' ? 'selected' : ''); ?>>Unverified</option>
            </select>
        </div>

        <div class="col-md-2">
            <select name="min_score" class="form-select form-select-sm" onchange="this.form.submit()">
                <option value="">Any Score</option>
                <?php $hb = \App\Support\ScoreBands::thresholds(); ?>
                <option value="<?php echo e($hb['high']); ?>" <?php echo e($minScore == $hb['high'] ? 'selected' : ''); ?>>High Priority (<?php echo e($hb['high']); ?>+ pts)</option>
                <option value="<?php echo e($hb['qualified']); ?>" <?php echo e($minScore == $hb['qualified'] ? 'selected' : ''); ?>>Qualified (<?php echo e($hb['qualified']); ?>+ pts)</option>
                <option value="<?php echo e($hb['nurture']); ?>" <?php echo e($minScore == $hb['nurture'] ? 'selected' : ''); ?>>Nurture+ (<?php echo e($hb['nurture']); ?>+ pts)</option>
            </select>
        </div>

        <div class="col-md-1 d-flex gap-1">
            <button type="submit" class="btn btn-sm btn-light border w-100" title="Apply Filters"><i class="bi bi-funnel"></i></button>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($search || $stage || $country || $verification || $minScore || $assignedTo): ?>
                <a href="<?php echo e(route('leads.index')); ?>" class="btn btn-sm btn-light border text-danger" title="Clear Filters"><i class="bi bi-x-lg"></i></a>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </form>
</div>

<!-- Leads Data Table -->
<div class="card-lp overflow-hidden mb-4">
    <div class="table-responsive">
        <table class="table table-lp align-middle">
            <thead>
                <tr>
                    <th>Prospect & Role</th>
                    <th>Company</th>
                    <th>Email Deliverability</th>
                    <th>Intent & Score</th>
                    <th>Lifecycle Stage</th>
                    <th>Assigned Rep</th>
                    <th class="text-end">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <tr>
                    <td>
                        <a href="<?php echo e(route('leads.show', $lead)); ?>" class="fw-bold text-dark text-decoration-none fs-6">
                            <?php echo e($lead->full_name); ?>

                        </a>
                        <div class="small text-muted"><?php echo e($lead->job_title ?: 'Role unknown'); ?></div>
                    </td>

                    <td>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($lead->company): ?>
                            <a href="<?php echo e(route('companies.show', $lead->company)); ?>" class="fw-semibold text-dark text-decoration-none">
                                <?php echo e($lead->company->name); ?>

                            </a>
                            <div class="small text-muted"><?php echo e($lead->country); ?></div>
                        <?php else: ?>
                            <span class="text-muted small">Independent / <?php echo e($lead->country); ?></span>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </td>

                    <td>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($lead->email): ?>
                            <div class="d-flex align-items-center gap-1">
                                <span class="text-dark small"><?php echo e($lead->email); ?></span>
                            </div>
                            <div>
                                <span class="badge <?php echo e($lead->email_verification_status === 'verified' ? 'bg-success-subtle text-success' : ($lead->email_verification_status === 'risky' ? 'bg-warning-subtle text-warning' : 'bg-secondary-subtle text-secondary')); ?>" style="font-size: 0.7rem;">
                                    <i class="bi <?php echo e($lead->email_verification_status === 'verified' ? 'bi-check-circle-fill' : 'bi-question-circle'); ?> me-1"></i>
                                    <?php echo e(ucfirst($lead->email_verification_status)); ?>

                                </span>
                            </div>
                        <?php else: ?>
                            <span class="text-muted small">No email</span>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </td>

                    <td>
                        <div class="d-flex align-items-center gap-2">
                            <span class="badge-lp <?php echo e(\App\Support\ScoreBands::badgeClass($lead->overall_score)); ?>">
                                <?php echo e($lead->overall_score); ?> / 100
                            </span>
                            <span class="small text-muted">(<?php echo e($lead->priority_badge); ?>)</span>
                        </div>
                        <div class="small text-muted mt-1" style="font-size: 0.725rem;">
                            Intent: <?php echo e($lead->intent_score); ?> | Fit: <?php echo e($lead->service_fit_score); ?>

                        </div>
                    </td>

                    <td>
                        <span class="badge bg-light text-dark border">
                            <?php echo e(ucwords(str_replace('_', ' ', $lead->lifecycle_stage))); ?>

                        </span>
                    </td>

                    <td>
                        <div class="small text-muted">
                            <?php echo e($lead->assignedUser?->name ?? 'Unassigned'); ?>

                        </div>
                    </td>

                    <td class="text-end">
                        <div class="btn-group btn-group-sm">
                            <a href="<?php echo e(route('leads.show', $lead)); ?>" class="btn btn-light border" title="View Profile">
                                <i class="bi bi-eye"></i>
                            </a>
                            <form action="<?php echo e(route('leads.rescore', $lead)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-light border" title="Re-evaluate 100-Point Score">
                                    <i class="bi bi-arrow-repeat text-primary"></i>
                                </button>
                            </form>
                            <a href="<?php echo e(route('leads.edit', $lead)); ?>" class="btn btn-light border" title="Edit Lead">
                                <i class="bi bi-pencil"></i>
                            </a>
                        </div>
                    </td>
                </tr>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                <tr>
                    <td colspan="7" class="text-center py-5 text-muted">
                        <i class="bi bi-person-x fs-1 d-block mb-2 opacity-50"></i>
                        No leads found matching current filter criteria.
                    </td>
                </tr>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($leads->hasPages()): ?>
    <div class="p-3 border-top bg-light-subtle d-flex justify-content-end">
        <?php echo e($leads->links()); ?>

    </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Leed_generation\resources\views/leads/index.blade.php ENDPATH**/ ?>