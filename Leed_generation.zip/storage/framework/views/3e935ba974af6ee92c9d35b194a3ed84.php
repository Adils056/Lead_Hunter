<?php $__env->startSection('title', $lead->full_name . ' — Lead Profile'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-4">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb mb-2" style="font-size: 0.825rem;">
            <li class="breadcrumb-item"><a href="<?php echo e(route('leads.index')); ?>">Leads</a></li>
            <li class="breadcrumb-item active"><?php echo e($lead->full_name); ?></li>
        </ol>
    </nav>

    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3">
        <div>
            <div class="d-flex align-items-center gap-2">
                <h3 class="fw-bold mb-0"><?php echo e($lead->full_name); ?></h3>
                <span class="badge bg-light text-dark border"><?php echo e(ucwords(str_replace('_', ' ', $lead->lifecycle_stage))); ?></span>
                <span class="badge-lp <?php echo e(\App\Support\ScoreBands::badgeClass($lead->overall_score)); ?>">
                    Score: <?php echo e($lead->overall_score); ?> / 100
                </span>
            </div>
            <div class="d-flex flex-wrap align-items-center gap-3 text-muted small mt-1">
                <span><i class="bi bi-briefcase me-1"></i><?php echo e($lead->job_title ?: 'Role unknown'); ?></span>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($lead->company): ?>
                    <span><i class="bi bi-building me-1"></i><a href="<?php echo e(route('companies.show', $lead->company)); ?>" class="text-decoration-none"><?php echo e($lead->company->name); ?></a></span>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <span><i class="bi bi-geo-alt me-1"></i><?php echo e($lead->country); ?></span>
                <span><i class="bi bi-person me-1"></i>Assigned: <?php echo e($lead->assignedUser?->name ?? 'Unassigned'); ?></span>
            </div>
        </div>

        <div class="d-flex gap-2 flex-wrap">
            <a href="<?php echo e(route('assistant.show', $lead)); ?>" class="btn btn-sm btn-primary-lp d-flex align-items-center gap-1 shadow-sm">
                <i class="bi bi-magic"></i>
                <span>Sales Assistant</span>
            </a>
            <form action="<?php echo e(route('leads.rescore', $lead)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-sm btn-outline-primary d-flex align-items-center gap-1 shadow-sm">
                    <i class="bi bi-arrow-repeat text-primary"></i>
                    <span>Re-Evaluate Score</span>
                </button>
            </form>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($lead->email): ?>
            <form action="<?php echo e(route('leads.verify-email', $lead)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-sm btn-outline-success d-flex align-items-center gap-1 shadow-sm">
                    <i class="bi bi-patch-check text-success"></i>
                    <span>Verify Deliverability</span>
                </button>
            </form>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <a href="<?php echo e(route('leads.edit', $lead)); ?>" class="btn btn-sm btn-light border d-flex align-items-center gap-1">
                <i class="bi bi-pencil"></i>
                <span>Edit</span>
            </a>
        </div>
    </div>
</div>

<div class="row g-4">
    <!-- Left Column: 100-Point Transparent Score Engine Breakdown -->
    <div class="col-lg-7">
        <!-- 100-Point Score Card -->
        <div class="card-lp p-4 mb-4">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <div class="d-flex align-items-center gap-2">
                    <span class="p-2 rounded bg-success-subtle text-success"><i class="bi bi-shield-check fs-5"></i></span>
                    <div>
                        <h6 class="fw-bold mb-0">100-Point Explainable Scoring Model</h6>
                        <span class="text-muted" style="font-size: 0.75rem;">Weighted evidence model (v<?php echo e($lead->score_breakdown['scoring_version'] ?? '1'); ?>) · weights set in Settings → Lead Scoring</span>
                    </div>
                </div>
                <div class="text-end">
                    <span class="fs-4 fw-bold <?php echo e(\App\Support\ScoreBands::textClass($lead->overall_score)); ?>">
                        <?php echo e($lead->overall_score); ?>

                    </span>
                    <span class="text-muted small">/ 100</span>
                </div>
            </div>

            <!-- Score Explanation Narrative -->
            <div class="p-3 rounded bg-light-subtle border mb-4">
                <strong class="d-block small text-dark fw-bold mb-1">
                    <i class="bi bi-chat-left-text-fill text-primary me-1"></i> Scoring Rationale
                </strong>
                <p class="small text-muted mb-0" style="line-height: 1.6;">
                    <?php echo e($lead->score_explanation ?: 'No scoring rationale generated yet.'); ?>

                </p>
            </div>

            <?php echo $__env->make('leads._score_panel', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>

        <!-- Outreach History & Inbound Replies -->
        <div class="card-lp p-4 mb-4">
            <h6 class="fw-bold mb-3"><i class="bi bi-envelope-paper text-primary me-1"></i> Outreach & Reply Activity</h6>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($lead->inboundReplies->isNotEmpty()): ?>
                <div class="mb-3">
                    <strong class="d-block small text-muted text-uppercase fw-bold mb-2">Inbound Responses (<?php echo e($lead->inboundReplies->count()); ?>)</strong>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $lead->inboundReplies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <div class="p-3 rounded border mb-2 <?php echo e($reply->classification === 'positive' || $reply->classification === 'meeting_request' ? 'bg-success-subtle border-success-subtle' : 'bg-light'); ?>">
                        <div class="d-flex justify-content-between align-items-center mb-1">
                            <span class="badge <?php echo e($reply->classification === 'positive' ? 'bg-success' : ($reply->classification === 'meeting_request' ? 'bg-primary' : 'bg-secondary')); ?>">
                                <?php echo e(ucwords(str_replace('_', ' ', $reply->classification))); ?> (<?php echo e($reply->ai_confidence); ?>% AI Conf)
                            </span>
                            <span class="small text-muted"><?php echo e($reply->received_at->format('M d, Y H:i')); ?></span>
                        </div>
                        <div class="fw-semibold text-dark small mb-1"><?php echo e($reply->subject); ?></div>
                        <div class="small text-muted" style="white-space: pre-wrap;"><?php echo e($reply->body_text); ?></div>
                    </div>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($lead->campaignRecipients->isNotEmpty()): ?>
                <div>
                    <strong class="d-block small text-muted text-uppercase fw-bold mb-2">Campaign Outreach History</strong>
                    <div class="table-responsive">
                        <table class="table table-sm table-lp align-middle">
                            <thead>
                                <tr class="text-muted small">
                                    <th>Campaign</th>
                                    <th>Status</th>
                                    <th>Dispatched At</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $lead->campaignRecipients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                <tr>
                                    <td>
                                        <div class="fw-semibold text-dark"><?php echo e($cr->campaign?->name ?? 'Direct'); ?></div>
                                        <div class="small text-muted"><?php echo e($cr->personalized_subject); ?></div>
                                    </td>
                                    <td>
                                        <span class="badge bg-light text-dark border"><?php echo e(ucfirst($cr->status)); ?></span>
                                    </td>
                                    <td class="small text-muted">
                                        <?php echo e($cr->sent_at ? $cr->sent_at->format('M d, Y H:i') : 'Draft / Scheduled'); ?>

                                    </td>
                                </tr>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php else: ?>
                <p class="text-muted small mb-0">No outbound campaign messages dispatched to this contact yet.</p>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>

    <!-- Right Column: Verification, CRM Tasks, Deals, Next Steps -->
    <div class="col-lg-5">
        <!-- Contact & Deliverability Status -->
        <div class="card-lp p-4 mb-4">
            <h6 class="fw-bold mb-3"><i class="bi bi-shield-check text-info me-1"></i> Deliverability & Compliance</h6>

            <div class="mb-3">
                <div class="d-flex justify-content-between align-items-center mb-1">
                    <span class="small text-muted">Direct Business Email:</span>
                    <span class="fw-semibold text-dark"><?php echo e($lead->email ?: 'None provided'); ?></span>
                </div>
                <div class="d-flex justify-content-between align-items-center mb-1">
                    <span class="small text-muted">Verification Status:</span>
                    <span class="badge <?php echo e($lead->email_verification_status === 'verified' ? 'bg-success-subtle text-success' : 'bg-warning-subtle text-warning'); ?> border">
                        <?php echo e(ucfirst($lead->email_verification_status)); ?>

                    </span>
                </div>
                <div class="d-flex justify-content-between align-items-center mb-1">
                    <span class="small text-muted">Global Suppression Check:</span>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($lead->isSuppressed()): ?>
                        <span class="badge bg-danger-subtle text-danger border">Suppressed (Do Not Contact)</span>
                    <?php else: ?>
                        <span class="badge bg-success-subtle text-success border">Clear (Outreach Permitted)</span>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
                <div class="d-flex justify-content-between align-items-center">
                    <span class="small text-muted">Phone:</span>
                    <span class="small text-dark"><?php echo e($lead->phone ?: 'Not provided'); ?></span>
                </div>
            </div>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($lead->email): ?>
            <form action="<?php echo e(route('leads.verify-email', $lead)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-sm btn-light border w-100">
                    <i class="bi bi-arrow-clockwise me-1"></i> Run DNS / MX Email Verification
                </button>
            </form>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>

        <!-- Follow-up Next Action -->
        <div class="card-lp p-4 mb-4" style="background: #faf5ff; border-color: #e9d5ff;">
            <h6 class="fw-bold mb-2 text-purple" style="color: #6b21a8;"><i class="bi bi-calendar-check me-1"></i> Next Action & Follow-up</h6>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($lead->next_action_date): ?>
                <div class="d-flex justify-content-between align-items-center mb-1">
                    <span class="small text-muted">Due Date:</span>
                    <strong class="text-dark small"><?php echo e($lead->next_action_date->format('M d, Y')); ?></strong>
                </div>
                <div class="small text-dark mt-1">
                    <?php echo e($lead->next_action_note ?: 'Follow up on outreach discussion.'); ?>

                </div>
            <?php else: ?>
                <p class="small text-muted mb-0">No scheduled follow-up task recorded.</p>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>

        <!-- Follow-up Tasks Modal Trigger -->
        <div class="card-lp p-4 mb-4">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h6 class="fw-bold mb-0"><i class="bi bi-check2-square text-success me-1"></i> Tasks (<?php echo e($lead->tasks->count()); ?>)</h6>
                <button type="button" class="btn btn-sm btn-light border py-1 px-2" data-bs-toggle="modal" data-bs-target="#addTaskModal">
                    <i class="bi bi-plus"></i> Add
                </button>
            </div>

            <div class="d-flex flex-column gap-2">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $lead->tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <div class="p-2 rounded border bg-light-subtle d-flex justify-content-between align-items-center">
                    <div>
                        <div class="small fw-semibold text-dark <?php echo e($t->status === 'completed' ? 'text-decoration-line-through text-muted' : ''); ?>">
                            <?php echo e($t->title); ?>

                        </div>
                        <div class="text-muted" style="font-size: 0.725rem;">Due <?php echo e($t->due_date->format('M d')); ?> • <?php echo e(ucfirst($t->priority)); ?> Priority</div>
                    </div>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($t->status !== 'completed'): ?>
                    <form action="<?php echo e(route('crm.tasks.complete', $t)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-sm btn-light border py-0 px-2" title="Mark Complete">
                            <i class="bi bi-check text-success"></i>
                        </button>
                    </form>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                <div class="text-muted small text-center py-2">No tasks logged.</div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Add Task Modal -->
<div class="modal fade" id="addTaskModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <form action="<?php echo e(route('crm.tasks.store')); ?>" method="POST" class="modal-content">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="lead_id" value="<?php echo e($lead->id); ?>">
            <input type="hidden" name="company_id" value="<?php echo e($lead->company_id); ?>">
            <div class="modal-header">
                <h5 class="modal-title fw-bold fs-6">Schedule Follow-up Task</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label class="form-label small fw-semibold">Task Title</label>
                    <input type="text" name="title" class="form-control" placeholder="e.g. Call to discuss ERP proposal" required>
                </div>
                <div class="row g-2 mb-3">
                    <div class="col-6">
                        <label class="form-label small fw-semibold">Due Date</label>
                        <input type="date" name="due_date" class="form-control" value="<?php echo e(date('Y-m-d', strtotime('+2 days'))); ?>" required>
                    </div>
                    <div class="col-6">
                        <label class="form-label small fw-semibold">Priority</label>
                        <select name="priority" class="form-select">
                            <option value="medium">Medium</option>
                            <option value="high">High</option>
                            <option value="urgent">Urgent</option>
                            <option value="low">Low</option>
                        </select>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label small fw-semibold">Assigned Rep</label>
                    <select name="assigned_to" class="form-select">
                        <option value="<?php echo e(Auth::id()); ?>"><?php echo e(Auth::user()->name); ?> (You)</option>
                    </select>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-light border" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-primary-lp">Create Task</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Leed_generation\resources\views/leads/show.blade.php ENDPATH**/ ?>