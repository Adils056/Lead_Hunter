<?php $__env->startSection('title', 'Sales CRM Pipeline'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
    <div>
        <h3 class="fw-bold mb-1">CRM Sales Pipeline</h3>
        <p class="text-muted small mb-0">Visual stage progression: from discovery to proposals, negotiations, and won enterprise contracts.</p>
    </div>

    <!-- Filters -->
    <form action="<?php echo e(route('crm.pipeline')); ?>" method="GET" class="d-flex gap-2">
        <select name="assigned_to" class="form-select form-select-sm" onchange="this.form.submit()">
            <option value="">All Representatives</option>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $salesReps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <option value="<?php echo e($rep->id); ?>" <?php echo e($assignedTo == $rep->id ? 'selected' : ''); ?>><?php echo e($rep->name); ?></option>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </select>
        <select name="country" class="form-select form-select-sm" onchange="this.form.submit()">
            <option value="">All Countries</option>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <option value="<?php echo e($c); ?>" <?php echo e($country == $c ? 'selected' : ''); ?>><?php echo e($c); ?></option>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </select>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($assignedTo || $country): ?>
            <a href="<?php echo e(route('crm.pipeline')); ?>" class="btn btn-sm btn-light border text-danger"><i class="bi bi-x-lg"></i></a>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </form>
</div>

<!-- Horizontal Scrolling Kanban Board -->
<div class="d-flex gap-3 overflow-auto pb-4" style="min-height: calc(100vh - 220px);">
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $pipelineStages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stageKey => $meta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
    <?php
        $leadsInStage = $columnLeads[$stageKey] ?? collect();
    ?>
    <div class="flex-shrink-0" style="width: 310px;">
        <!-- Column Header -->
        <div class="p-3 rounded-top border-bottom bg-white border d-flex justify-content-between align-items-center shadow-xs">
            <div class="d-flex align-items-center gap-2">
                <span class="rounded-circle bg-<?php echo e($meta['color']); ?>" style="width: 10px; height: 10px;"></span>
                <span class="fw-bold text-dark small"><?php echo e($meta['label']); ?></span>
            </div>
            <span class="badge bg-light text-secondary border small"><?php echo e($leadsInStage->count()); ?></span>
        </div>

        <!-- Column Body -->
        <div class="p-2 bg-light-subtle rounded-bottom border border-top-0 d-flex flex-column gap-2" style="min-height: 480px;">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $leadsInStage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
            <div class="card-lp p-3 bg-white shadow-xs">
                <div class="d-flex justify-content-between align-items-start mb-2">
                    <span class="badge-lp <?php echo e(\App\Support\ScoreBands::badgeClass($lead->overall_score)); ?>">
                        <?php echo e($lead->overall_score); ?> pts
                    </span>
                    <div class="dropdown">
                        <button class="btn btn-sm btn-light py-0 px-1 text-muted border-0" data-bs-toggle="dropdown">
                            <i class="bi bi-three-dots-vertical"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end small shadow-sm">
                            <li><h6 class="dropdown-header small">Move to Stage</h6></li>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $pipelineStages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $targetKey => $targetMeta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($targetKey !== $stageKey): ?>
                                <li>
                                    <form action="<?php echo e(route('crm.pipeline.stage', $lead)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="lifecycle_stage" value="<?php echo e($targetKey); ?>">
                                        <button type="submit" class="dropdown-item py-1">
                                            <?php echo e($targetMeta['label']); ?>

                                        </button>
                                    </form>
                                </li>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="<?php echo e(route('leads.show', $lead)); ?>"><i class="bi bi-eye me-1"></i>View Profile</a></li>
                        </ul>
                    </div>
                </div>

                <a href="<?php echo e(route('leads.show', $lead)); ?>" class="fw-bold text-dark text-decoration-none d-block fs-6 mb-1">
                    <?php echo e($lead->full_name); ?>

                </a>

                <div class="small text-muted mb-2">
                    <i class="bi bi-building me-1"></i><?php echo e($lead->company?->name ?? 'Direct'); ?>

                    <span class="mx-1">•</span>
                    <?php echo e($lead->country); ?>

                </div>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($lead->deals->isNotEmpty()): ?>
                <div class="p-1 px-2 rounded bg-success-subtle border border-success-subtle text-success small fw-bold mb-2 d-flex justify-content-between align-items-center" style="font-size: 0.75rem;">
                    <span><i class="bi bi-cash me-1"></i><?php echo e($lead->deals->first()->title); ?></span>
                    <span>$<?php echo e(number_format($lead->deals->first()->value)); ?></span>
                </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                <div class="d-flex justify-content-between align-items-center pt-2 border-top text-muted" style="font-size: 0.725rem;">
                    <span><i class="bi bi-person me-1"></i><?php echo e($lead->assignedUser?->name ?? 'Unassigned'); ?></span>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($lead->email_verification_status === 'verified'): ?>
                        <i class="bi bi-check-circle-fill text-success" title="Verified Deliverable"></i>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            <div class="text-center py-4 text-muted small opacity-75">
                No prospects in this stage
            </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Leed_generation\resources\views/crm/pipeline.blade.php ENDPATH**/ ?>