<?php $__env->startSection('title', 'Autopilot'); ?>
<?php $__env->startSection('content'); ?>
<?php
    $hbOk = fn($c) => isset($heartbeats[$c]) && $heartbeats[$c]->beat_at->gt(now()->subMinutes(config('leadpilot.incidents.heartbeat_stale_minutes')));
    $stateOrder = \App\Services\Autopilot\LeadStateService::STATES;
?>
<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
    <div>
        <h3 class="fw-bold mb-1">Autopilot</h3>
        <p class="text-muted small mb-0">The system works on its own and stops only for exceptions. Times shown in <?php echo e(config('leadpilot.timezone')); ?>.</p>
    </div>
    <div class="d-flex gap-2 flex-wrap">
        <a href="<?php echo e(route('approvals.index')); ?>" class="btn btn-sm <?php echo e($summary['pending_approvals'] ? 'btn-warning' : 'btn-light border'); ?>"><i class="bi bi-check2-square"></i> Approvals <span class="badge bg-dark"><?php echo e($summary['pending_approvals']); ?></span></a>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->user()->isAdmin()): ?>
        <a href="<?php echo e(route('autopilot.setup')); ?>" class="btn btn-sm btn-light border"><i class="bi bi-heart-pulse"></i> Setup &amp; health</a>
        <a href="<?php echo e(route('autopilot.policy')); ?>" class="btn btn-sm btn-light border"><i class="bi bi-sliders"></i> Autonomy &amp; budgets</a>
        <form method="POST" action="<?php echo e(route('autopilot.run')); ?>"><?php echo csrf_field(); ?><button class="btn btn-sm btn-primary-lp"><i class="bi bi-play-fill"></i> Run cycle now</button></form>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>
</div>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $incidents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
<div class="alert <?php echo e($i->severity === 'critical' ? 'alert-danger' : 'alert-warning'); ?> d-flex justify-content-between align-items-start gap-3">
    <div><strong>🚨 <?php echo e($i->title); ?></strong> <span class="small text-muted">#<?php echo e($i->id); ?> · <?php echo e($i->created_at->diffForHumans()); ?></span><div class="small"><?php echo e($i->details); ?></div></div>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->user()->isAdmin()): ?>
    <form method="POST" action="<?php echo e(route('autopilot.incident.resolve', $i)); ?>"><?php echo csrf_field(); ?><input type="hidden" name="resume" value="1"><button class="btn btn-sm btn-outline-dark">Resolve &amp; resume</button></form>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</div>
<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>

<div class="row g-3 mb-4">
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = [['New leads today', $stats['new_leads']], ['Ready / qualified', $stats['qualified']], ['Emails sent today', $stats['sent_today']], ['Replies today', $stats['replies_today']], ['Spend today', '$' . number_format($stats['spend_today'], 2)], ['Spend this month', '$' . number_format($stats['spend_month'], 2)]]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$l, $v]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
    <div class="col-6 col-md-2"><div class="card-lp p-3 h-100"><div class="small text-muted"><?php echo e($l); ?></div><div class="fs-4 fw-bold"><?php echo e($v); ?></div></div></div>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
</div>

<div class="row g-4">
    <div class="col-lg-7">
        <div class="card-lp p-3 mb-4">
            <h6 class="fw-bold mb-2">Needs your decision</h6>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $approvals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <a href="<?php echo e(route('approvals.show', $a)); ?>" class="d-flex justify-content-between border-bottom py-2 text-decoration-none text-dark small">
                    <span><span class="badge <?php echo e(in_array($a->priority, ['critical','high']) ? 'bg-danger' : 'bg-secondary'); ?> me-1"><?php echo e($a->priority); ?></span><?php echo e($a->title); ?></span>
                    <span class="text-muted"><?php echo e($a->due_at && $a->due_at->isPast() ? 'overdue' : 'due ' . $a->due_at?->diffForHumans()); ?></span>
                </a>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                <p class="small text-muted mb-0">Nothing waiting. ✔</p>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
        <div class="card-lp p-3 mb-4">
            <h6 class="fw-bold mb-2">Pipeline</h6>
            <div class="d-flex flex-wrap gap-2">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $stateOrder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <span class="badge bg-light text-dark border p-2"><?php echo e($label); ?> <strong class="ms-1"><?php echo e($states[$k] ?? 0); ?></strong></span>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </div>
            <div class="small text-muted mt-2">A high score never means "send". Only leads that pass the eligibility gate become <em>Eligible for outreach</em>.</div>
        </div>
        <div class="card-lp p-3">
            <h6 class="fw-bold mb-2">Where Autopilot is searching (learned)</h6>
            <table class="table table-sm small mb-0"><thead><tr class="text-muted"><th>ICP</th><th>Source</th><th>Runs</th><th>Leads</th><th>Qualified</th><th>Positive</th><th>$</th><th>Status</th></tr></thead><tbody>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $arms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <tr><td><?php echo e($arm->icpProfile?->name); ?></td><td><?php echo e($arm->source_slug); ?></td><td><?php echo e($arm->runs); ?></td><td><?php echo e($arm->leads); ?></td><td><?php echo e($arm->qualified); ?></td><td><?php echo e($arm->positive); ?></td><td><?php echo e(number_format($arm->cost_cents / 100, 2)); ?></td>
                    <td><?php echo e($arm->exhausted_until && $arm->exhausted_until->isFuture() ? 'resting until ' . $arm->exhausted_until->format('M d') : 'active'); ?></td></tr>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?> <tr><td colspan="8" class="text-muted">No searches yet.</td></tr> <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </tbody></table>
        </div>
    </div>
    <div class="col-lg-5">
        <div class="card-lp p-3 mb-4">
            <h6 class="fw-bold mb-2">System</h6>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = ['scheduler' => 'Scheduler', 'queue_worker' => 'Queue worker', 'autopilot' => 'Last autopilot cycle', 'reply_sync' => 'Reply sync']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c => $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <div class="d-flex justify-content-between small py-1 border-bottom"><span><?php echo e($l); ?></span>
                    <span class="<?php echo e($hbOk($c) ? 'text-success' : 'text-danger'); ?>"><?php echo e(isset($heartbeats[$c]) ? $heartbeats[$c]->beat_at->diffForHumans() : 'never'); ?></span></div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </div>
        <div class="card-lp p-3 mb-4">
            <h6 class="fw-bold mb-2">Workflows</h6>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $workflows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w => $st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <div class="d-flex justify-content-between align-items-center small py-1 border-bottom">
                    <span><?php echo e(ucfirst(str_replace('_', ' ', $w))); ?> <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($st['paused']): ?><span class="badge bg-danger">paused</span><div class="text-muted" style="font-size:.72rem"><?php echo e($st['reason']); ?></div><?php else: ?><span class="badge bg-success">running</span><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?></span>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->user()->isAdmin()): ?>
                    <form method="POST" action="<?php echo e(route('autopilot.workflow', $w)); ?>"><?php echo csrf_field(); ?><input type="hidden" name="pause" value="<?php echo e($st['paused'] ? 0 : 1); ?>"><button class="btn btn-sm btn-link p-0"><?php echo e($st['paused'] ? 'Resume' : 'Pause'); ?></button></form>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </div>
        <div class="card-lp p-3">
            <h6 class="fw-bold mb-2">Integrations</h6>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $providers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slug => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <div class="d-flex justify-content-between small py-1 border-bottom"><span><?php echo e($p['label']); ?> <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($p['paid']): ?><span class="badge bg-light text-dark border">paid</span><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?></span>
                    <span class="<?php echo e(!$p['configured'] ? 'text-muted' : ($p['verified_at'] && $p['status'] === 'healthy' ? 'text-success' : ($p['status'] === 'disabled' ? 'text-danger' : 'text-warning'))); ?>">
                        <?php echo e(!$p['configured'] ? 'not configured' : ($p['verified_at'] ? $p['status'] . ' · verified ' . $p['verified_at']->diffForHumans() : 'not yet verified')); ?></span></div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            <div class="small text-muted mt-2">Local data © OpenStreetMap contributors (ODbL) and Overture Maps Foundation places (CDLA-Permissive-2.0 / Apache-2.0 per source).</div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Leed_generation\resources\views/autopilot/index.blade.php ENDPATH**/ ?>